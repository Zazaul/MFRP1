﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class PolicyDetail : System.Web.UI.Page
{
    Data_acces_layer obj = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        Literal1.Text = Session["id"].ToString();
        DataTable dt = new DataTable();
        DetailsView1.DataSource = obj.FunDataTable("select * from policy_registration where CustomerId = "+Session["id"]+" and insuranceName = '"+Session["insName"]+"'");
        DetailsView1.DataBind();
    }
    protected void Approve_Click(object sender, EventArgs e)
    {
        int a = obj.FunExecuteNonQuery("update policy_registration set sta = 'Y' where CustomerId = " + Session["id"] + " and insuranceName = '" + Session["insName"] + "'");
        if (a > 0)
            Literal2.Text = "Policy Approved Successfully";
        else
            Literal2.Text = "Approval failed";
    }
    protected void Reject_Click(object sender, EventArgs e)
    {
        int a = obj.FunExecuteNonQuery("update policy_registration set sta = 'N' where CustomerId = " + Session["id"] + " and insuranceName = '" + Session["insName"] + "'");
        if (a > 0)
            Literal2.Text = "Policy Rejected Successfully";
        else
            Literal2.Text = "Rejection failed";
    }
}