﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_password : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //int a = 5;
        object x = ob.FunExecuteScalar("select Password from customer_registration where Customer_Id=" + Session["r"] + "");
        string s = Convert.ToString(x);
        if (s == oldpass.Text)
        {
            int a = ob.FunExecuteNonQuery("update customer_registration set password='" + newpass.Text + "' where customer_Id=" + Session["r"] + "");
            if (a > 0)
                Literal1.Text = "Password successfully changed";
            else
                Literal1.Text = "Password not changed";
        }
        else
            Literal1.Text = "Old Password is incorrect";
    }
}