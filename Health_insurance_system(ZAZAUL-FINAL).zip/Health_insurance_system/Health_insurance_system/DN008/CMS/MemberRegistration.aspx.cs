﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MemberRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void nomineecombobox_SelectedIndexChanged(object sender, EventArgs e)
    {
        
        if (nomineecombobox.Text.Equals("1"))
        {
            nominee1.Visible = true;
            nominee2.Visible = false;
            nominee3.Visible = false;

        }
        else if (nomineecombobox.Text.Equals("2"))
        {
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = false;
        }
        else if (nomineecombobox.Text.Equals("3"))
        {
            nominee1.Visible = true;
            nominee2.Visible = true;
            nominee3.Visible = true;
        }
    }
}