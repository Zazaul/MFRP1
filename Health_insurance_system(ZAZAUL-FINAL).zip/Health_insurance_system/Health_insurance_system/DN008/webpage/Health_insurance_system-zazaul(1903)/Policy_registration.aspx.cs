﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Policy_registration : System.Web.UI.Page
{
    Data_acces_layer obj = new Data_acces_layer();
    SqlDataReader sdr;

    protected void Page_Load(object sender, EventArgs e)
    {
        #region Load Insurance name on page load
        if (!IsPostBack)
        {
            InsuranceNameDropdownList.DataSource = obj.FunDataTable("select * from insurancetype");
            InsuranceNameDropdownList.AppendDataBoundItems = true;
            InsuranceNameDropdownList.DataTextField = "insName";
            InsuranceNameDropdownList.DataValueField = "insName";
            InsuranceNameDropdownList.DataBind();
        }
        #endregion
    }

    protected void InsuranceNameDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate policy amount Dropdown list
        PolicyAmountDropdownList.Items.Clear();
        PolicyAmountDropdownList.DataSource = obj.FunDataTable("select polAmount from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + InsuranceNameDropdownList.SelectedValue.ToString() + "'");
        PolicyAmountDropdownList.AppendDataBoundItems = true;
        PolicyAmountDropdownList.Items.Insert(0, new ListItem("Select Policy Amount", null));
        PolicyAmountDropdownList.DataTextField = "polAmount";
        PolicyAmountDropdownList.DataValueField = "polAmount";
        PolicyAmountDropdownList.DataBind();
        #endregion
    }

    protected void PolicyAmountDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate policy Duration Dropdown list
        PolicyDurationDropdownList.Items.Clear();
        PolicyDurationDropdownList.DataSource = obj.FunDataTable("select * from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + InsuranceNameDropdownList.SelectedValue.ToString() + "'and polAmount = "+Convert.ToInt32(PolicyAmountDropdownList.SelectedValue) +"");
        PolicyDurationDropdownList.AppendDataBoundItems = true;
        PolicyDurationDropdownList.Items.Insert(0, new ListItem("Select Policy Duration", null));
        PolicyDurationDropdownList.DataTextField = "duration";
        PolicyDurationDropdownList.DataValueField = "duration";
        PolicyDurationDropdownList.DataBind();
        #endregion    
    }

    protected void PolicyDurationDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate Premium Type Dropdown list
        PremiumTypeDropDownList.Items.Clear();
        PremiumTypeDropDownList.DataSource = obj.FunDataTable("select * from policy_registration where insuranceName = '" + InsuranceNameDropdownList.SelectedValue.ToString() + "'");
        PremiumTypeDropDownList.AppendDataBoundItems = true;
        PremiumTypeDropDownList.Items.Insert(0, new ListItem("Select Premium Type", null));
        PremiumTypeDropDownList.DataTextField = "premiumType";
        PremiumTypeDropDownList.DataValueField = "premiumType";
        PremiumTypeDropDownList.DataBind();
        #endregion  
    }


    protected void ApplyButton_Click(object sender, EventArgs e)
    {
  
        int a = obj.FunExecuteNonQuery("exec usp_P_r_insert'" + Session["s"]+ "','" +InsuranceNameDropdownList.SelectedItem.Text + "','" + DateTime.Parse(PolicyStartDateTextBox.Text) + "','" + Convert.ToInt32(DiscountTextbox.Text) + "'," + Convert.ToInt32(PremiumAmountTextbox.Text) + "," + DateTime.Parse(MaturityDateTextbox.Text) + "," + Session["s"] + "," +DateTime.Now + "'");
           
        if (a > 0)
            {
                int count = obj.FunExecuteNonQuery("Select count(*) from Policyclaim");
                int policy_no = 1000 + count;
                if (policy_no <= 9999)
                {
                    policy_No.Text = "Policy Number is " + Convert.ToString(policy_no);
                }
                int b = obj.FunExecuteNonQuery("Insert into Policyclaim(CustomerId,policyNo) values(" + Session["r"] + "," + policy_no + ")");
                Response.Write("Registered successfuly");
            }
            else
            {
                Response.Write("Register again");
            }
        //int policy_no = 1000;
       
        //int a = obj.FunExecuteNonQuery("exec usp_P_r_insert '"+Convert.ToInt32()+"'");
      
    }
    protected void PolicyStartDateTextBox_TextChanged(object sender, EventArgs e)
    {
        #region Submit policy registration
        object percentage = obj.FunExecuteScalar("select percentage from policyamount join durationweightage on policyamount.duration = durationweightage.duration join weightage on discountWeightage = weightage where policyamount.polAmount=" + PolicyAmountDropdownList.SelectedValue + " and insurancetype.insName='" + InsuranceNameDropdownList.SelectedValue + "' and policyamount.duration=" + PolicyDurationDropdownList.SelectedValue + " and weightage.premiumType='" + PremiumTypeDropDownList.SelectedValue + "'");
        double premiumamount = obj.calulatePremiuim(double.Parse(PolicyAmountDropdownList.SelectedValue), int.Parse(PolicyDurationDropdownList.SelectedValue), Convert.ToString(PremiumTypeDropDownList.SelectedValue), (float)(percentage));
        DiscountTextbox.Text = Convert.ToString((int)percentage);
        PremiumAmountTextbox.Text = Convert.ToString((int)premiumamount);
        DateTime start_date = DateTime.Parse(PolicyStartDateTextBox.ToString());
        DateTime MaturityDate = obj.MaturityDate(start_date, Convert.ToInt32(PolicyDurationDropdownList.SelectedValue));
        MaturityDateTextbox.Text = Convert.ToString(MaturityDate);
         #endregion
    }
}