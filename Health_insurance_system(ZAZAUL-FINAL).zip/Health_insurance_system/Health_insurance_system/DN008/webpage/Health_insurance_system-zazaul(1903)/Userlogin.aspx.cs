﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
   Data_acces_layer dalObj = new Data_acces_layer();
    SqlDataReader dr;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Register_Click(object sender, EventArgs e)
    {
        Response.Redirect("Customer_registration1.aspx");
    }
    protected void Reset_Click(object sender, EventArgs e)
    {
        Userid.Text = "";
        Password.Text = "";
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        dr = dalObj.ExecuteReader("select Customer_Id, Password from customer_registration where Customer_Id="+Userid.Text+" and Password='"+Password.Text+"'");
        if (dr.Read())
        {
            Session["r"] = dr[0];
            Session.Timeout = 30;
            Response.Redirect("User.aspx");
        }
        else
        {
            Invalidcredential.Text = "Invalid UserID/Password";
        }
    }
}