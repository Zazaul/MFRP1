﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class Login : System.Web.UI.Page
{
    Data_acces_layer dalObj = new Data_acces_layer();
    SqlDataReader dr;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Register_Click(object sender, EventArgs e)
    {
        Response.Redirect("Customer_registration1.aspx");
    }
    protected void Reset_Click(object sender, EventArgs e)
    {
        Userid.Text = "";
        Password.Text = "";
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        dr = dalObj.ExecuteReader("The Stored Procedure goes here");
        if (dr.Read())
        {
            if (dr.ToString().ToLower()[0] == 'a')
            {
                Session["User"] = dr[0];
                Session.Timeout = 10;
                Response.Redirect("Admin.aspx");
            }
            else
            {
                Session["User"] = dr[0];
                Session.Timeout = 10;
                Response.Redirect("User.aspx");
            }
        }
        else
        {
            Invalidcredential.Text = "Invalid UserID/Password";
        }
    }
}