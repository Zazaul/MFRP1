﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class Edit : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            InsuranceTypeDropDownList.DataSource = ob.FunDataTable("select * from insurancetype where insName in(select insuranceName from policy_registration where customerId in(select Customer_Id from customer_registration where Customer_Id=" +1+ "))");
            InsuranceTypeDropDownList.AppendDataBoundItems = true;
            
            InsuranceTypeDropDownList.DataTextField = "insType";
            InsuranceTypeDropDownList.DataValueField = "insType";
            InsuranceTypeDropDownList.DataBind();
        }
    }

    protected void InsuranceTypeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        PolicyAmountDropDownList.Items.Clear();
        PolicyAmountDropDownList.DataSource = ob.FunDataTable("select * from policyamount where polAmount in(select policyAmount from policy_registration where insuranceName in(select insName from insurancetype where insType=" + InsuranceTypeDropDownList.SelectedValue.ToString() + ") and customerId in(select Customer_Id from customer_registration where Customer_Id=" + Session["r"]+ "))");
        PolicyAmountDropDownList.AppendDataBoundItems = true;
        PolicyAmountDropDownList.Items.Insert(0, new ListItem("select amount", null));
        PolicyAmountDropDownList.DataTextField = "polAmount";
        PolicyAmountDropDownList.DataValueField = "polAmount";
        PolicyAmountDropDownList.DataBind();
    }
    protected void PolicyAmountDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        PolicyDurationDropDownList.Items.Clear();
        PolicyDurationDropDownList.DataSource = ob.FunDataTable("select * from policyamount where polAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + " and polAmount in(select policyAmount from policy_registration where insuranceName in(select insName from insurancetype where insType=" + InsuranceTypeDropDownList.SelectedValue.ToString() + ") and customerId in(select Customer_Id from customer_registration where Customer_Id=" + Session["r"] + "))");
        PolicyDurationDropDownList.AppendDataBoundItems = true;
        PolicyDurationDropDownList.Items.Insert(0, new ListItem("select duration", null));
        PolicyDurationDropDownList.DataTextField = "duration";
        PolicyDurationDropDownList.DataValueField = "duration";
        PolicyDurationDropDownList.DataBind();
    }

    protected void ApplyButton_Click(object sender, EventArgs e)
    {
      //int a= ob.FunExecuteNonQuery("exec usp_edit1'" + InsuranceTypeDropDownList.Text+"'");
      int b = ob.FunExecuteNonQuery("exec usp_policy_amt'" + PolicyAmountDropDownList.Text + "'");
      int c = ob.FunExecuteNonQuery("exec usp_policy_dur'" + PolicyDurationDropDownList.Text + "'");
        if(b>0 && c>0)
        {
            Response.Write("Policy updated!!");
        }
        else
            Response.Write("Policy updation unsuccessful");
    }
}