﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class User_password : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string s=Convert.ToString(ob.FunDataTable("select Password from customer_registration where Customer_Id="+Session['r']+"'"));
        if(s==oldpass.Text)
        {
            int a = ob.FunExecuteNonQuery("exec usp_userpassword" + newpass.Text + "'");
            if(a>0)
                Response.Write("Password changed successfully");
            else
                Response.Write("Password not changed");
        }
        else
            Response.Write("Old Password is incorrect");
    }
}