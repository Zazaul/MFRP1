﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;

public partial class Edit : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
            InsuranceTypeDropDownList.DataSource = ob.FunDataTable("select * from insurancetype where insName in(select insuranceName from policy_registration where customerId in(select Customer_Id from customer_registration where Customer_Id=" +Session["r"]+ "))");
            InsuranceTypeDropDownList.AppendDataBoundItems = true;
            
            InsuranceTypeDropDownList.DataTextField = "insName";
            InsuranceTypeDropDownList.DataValueField = "insType";
            InsuranceTypeDropDownList.DataBind();
        }
    }

    protected void InsuranceTypeDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        PolicyAmountDropDownList.Items.Clear();
        PolicyAmountDropDownList.DataSource = ob.FunDataTable("select * from policyamount p join insurancetype i on i.insType=p.insType where i.insName='"+InsuranceTypeDropDownList.SelectedItem.Text+"'");
        PolicyAmountDropDownList.AppendDataBoundItems = true;
        PolicyAmountDropDownList.Items.Insert(0, new ListItem("select amount", null));
        PolicyAmountDropDownList.DataTextField = "polAmount";
        PolicyAmountDropDownList.DataValueField = "polAmount";
        PolicyAmountDropDownList.DataBind();
    }
    protected void PolicyAmountDropDownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        PolicyDurationDropDownList.Items.Clear();
        PolicyDurationDropDownList.DataSource = ob.FunDataTable("select * from policyamount p join insurancetype i on i.insType=p.insType where i.insName='" + InsuranceTypeDropDownList.SelectedItem.Text + "' and p.polAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + "");
        PolicyDurationDropDownList.AppendDataBoundItems = true;
        PolicyDurationDropDownList.Items.Insert(0, new ListItem("select duration", null));
        PolicyDurationDropDownList.DataTextField = "duration";
        PolicyDurationDropDownList.DataValueField = "duration";
        PolicyDurationDropDownList.DataBind();
    }
  
    protected void ApplyButton_Click(object sender, EventArgs e)
    {
        int b = ob.FunExecuteNonQuery("update policy_registration set policyAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + " where customerId="+Session["r"]+" and insuranceName='"+InsuranceTypeDropDownList.SelectedItem.Text+"' and sta = 'P'");

        if (b > 0)
        {
            object premiumtype = ob.FunExecuteScalar("select distinct(w.premiumType) from weightage w join policy_registration pr on w.premiumType=pr.premiumType where pr.customerId=" + Session["r"] + " and pr.policyDuration in(select policyDuration from policy_registration where policyAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + ") and pr.policyAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + " and pr.insuranceName='" + InsuranceTypeDropDownList.SelectedItem.Text + "'");
            object percentage = ob.FunExecuteScalar("select w.percentage from weightage w join durationweightage dr on w.weightage=dr.discountWeightage where w.premiumType='" + premiumtype + "' and dr.duration=" + PolicyDurationDropDownList.SelectedValue.ToString() + "");
            double premiumamount = ob.calulatePremiuim(Convert.ToDouble(PolicyAmountDropDownList.SelectedValue.ToString()), Convert.ToInt32(PolicyDurationDropDownList.SelectedValue.ToString()), Convert.ToString(premiumtype), Convert.ToSingle(percentage));

            int c = ob.FunExecuteNonQuery("update policy_registration set policyDuration=" + PolicyDurationDropDownList.SelectedValue.ToString() + ",premiumAmount=" + premiumamount + ",premiumType='" + premiumtype.ToString() + "',discount=" + percentage.ToString() + " where customerId=" + Session["r"].ToString() + "and insuranceName='" + InsuranceTypeDropDownList.SelectedItem.Text + "'and policyAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + "and policyDuration in(select policyDuration from policy_registration where policyAmount=" + PolicyAmountDropDownList.SelectedValue.ToString() + ")");
            if (c > 0)
            {
                Literal1.Text = "Policy updated!!";
            }
            else
                Literal1.Text = "Policy updation unsuccessful";
        }
        else
            Literal1.Text = "This Policy is already approved";
    }
       

}