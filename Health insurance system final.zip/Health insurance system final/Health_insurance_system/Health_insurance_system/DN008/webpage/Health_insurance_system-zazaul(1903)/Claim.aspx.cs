﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;
public partial class Claim : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ClaimTypeText.DataSource = ob.FunDataTable("select * from claim_type");
            ClaimTypeText.DataTextField = "claimtype";
            ClaimTypeText.DataValueField = "ClaimId";
            ClaimTypeText.DataBind();
        }
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        object check = ob.FunExecuteScalar("select CustomerId from policyclaim where name='"+Name.Text+"' and CustomerId="+Session["r"]+" and policyNo="+PolicyNoText.Text+" and Active='Y'");
        if (Convert.ToString(check) != " ")
        {
            int claim1;
            int claim2;
            if (DeathCertificateButton.Checked)
            {
                claim1 = ob.FunExecuteNonQuery("insert into policyclaim(claimId,deathCertificate) values(" + ClaimTypeText.SelectedValue.ToString() + ",'Available') where name='" + Name.Text + "' and CustomerId=" + Session["r"] + " and policyNo=" + PolicyNoText.Text + "");
                Response.Write("Claim submitted");
            }
            else
            {
                claim2 = ob.FunExecuteNonQuery("insert into policyclaim(claimId,deathCertificate) values(" + ClaimTypeText.SelectedValue.ToString() + ",'NotAvailable') where name='" + Name.Text + "' and CustomerId=" + Session["r"] + " and policyNo=" + PolicyNoText.Text + "");
                Response.Write("Claim submitted");
            }
        }
        else
        {
            Response.Write("your request is not yet approve by Admin");
        }
    }
}