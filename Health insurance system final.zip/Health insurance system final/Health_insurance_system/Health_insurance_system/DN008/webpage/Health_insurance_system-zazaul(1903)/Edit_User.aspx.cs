﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;
public partial class EditUser : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int a=0, b=0, c=0;
        if(user_name.Text!="")
        {
             a=ob.FunExecuteNonQuery("exec usp_user_edit_name'"+user_name.Text+"'");
        }
        if(mail.Text!="")
        {
             b=ob.FunExecuteNonQuery("exec usp_user_edit_email'"+mail.Text+"'");
        }
        if(phone.Text!="")
        {
             c=ob.FunExecuteNonQuery("exec usp_user_edit_contact'"+phone.Text+"'");
        }
        if(a>0 || b>0 || c>0)
            Response.Write("Your details have been updated successfully");
        else
            Response.Write("Profile updation uns");
    }
    protected void ChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("User_password.aspx");
    }
}