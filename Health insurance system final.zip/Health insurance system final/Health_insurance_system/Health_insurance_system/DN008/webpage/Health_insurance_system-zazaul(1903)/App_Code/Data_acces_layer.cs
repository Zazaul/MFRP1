﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
#region namespaces used
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
#endregion

public class Data_acces_layer
{
    #region Variable
    SqlConnection con;
    SqlCommand cmd;
    SqlDataReader dr;
    SqlDataAdapter da;
    int ExecuteNonQuery;
    object ExecuteScalar;
    DataTable dt;
    DataSet ds;
    #endregion


    #region Function for OpenConnection
    public void OpenConnection()
    {
        if (con == null)
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["connection"].ToString());
        if (con.State == ConnectionState.Closed)
            con.Open();
    }
    #endregion


    #region Fuction for CloseConnection
    public void CloseConnection()
    {
        if (con.State == ConnectionState.Open)
            con.Close();
    }
    #endregion


    #region Function for ExecuteNonQuery(Insert,Update,Delete)
    public int FunExecuteNonQuery(string c)
    {
        OpenConnection();
        cmd = new SqlCommand(c, con);
        ExecuteNonQuery = cmd.ExecuteNonQuery();
        CloseConnection();
        return ExecuteNonQuery;
    }
    #endregion


    #region function for exscute scalar (fetch single detail from a row)
    public object FunExecuteScalar(string c)
    {
        OpenConnection();
        cmd = new SqlCommand(c, con);
        ExecuteScalar = cmd.ExecuteScalar();
        CloseConnection();
        return ExecuteScalar;
    }
    #endregion

    #region Function for execute reader(fetch row details)
    public SqlDataReader ExecuteReader(string c)
    {
        OpenConnection();
        cmd = new SqlCommand(c, con);
        dr = cmd.ExecuteReader();
        return dr;
    }
    #endregion

    #region Function for DataSet(Disconnected Mode)
    public DataSet FunDataSet(string c)
    {
        OpenConnection();
        da = new SqlDataAdapter(c, con);
        ds = new DataSet();
        da.Fill(ds);
        CloseConnection();
        return ds;
    }
    #endregion

    #region Function for DataTable
    public DataTable FunDataTable(string c)
    {
        OpenConnection();
        da = new SqlDataAdapter(c, con);
        dt = new DataTable();
        da.Fill(dt);
        CloseConnection();
        return dt;
    }
    #endregion

    #region Function for calculating Premium Amount and Maturity Date

    public double calulatePremiuim(double policyAmount, int duration, string premiuimType, float percentage)
    {
        double x ;
        if (premiuimType == "HY")
        {
            x = (policyAmount / 2*duration) - (((policyAmount /2*duration)*percentage) / 100);
        }
        else
            x = (policyAmount / duration) - (((policyAmount / duration)*percentage) / 100);
        
        return x;
    }

    public DateTime MaturityDate(DateTime startDate, int Duration)
    {
        return startDate.AddYears(Duration);
    }

   
    #endregion
}