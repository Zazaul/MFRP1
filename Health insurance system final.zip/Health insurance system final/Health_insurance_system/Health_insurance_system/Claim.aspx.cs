﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;
using Data_access_layer;

public partial class Claim : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ClaimTypeText.DataSource = ob.FunDataTable("select * from claim_type");
            ClaimTypeText.AppendDataBoundItems = true;
            ClaimTypeText.Items.Insert(0, new ListItem("Select Claim Type", null));
            ClaimTypeText.DataTextField = "claimtype";
            ClaimTypeText.DataValueField = "ClaimId";
            ClaimTypeText.DataBind();
        }
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        object check = ob.FunExecuteScalar("select customer_registration.Customer_Id from customer_registration join policyclaim on customer_registration.Customer_Id = policyclaim.CustomerId join policy_registration on policy_registration.customerId=customer_registration.Customer_Id where customer_registration.Name='" + Name.Text + "' and policyclaim.CustomerId=" + Session["r"] + " and policyclaim.policyNo=" + PolicyNoText.Text + " and policy_registration.sta='Y'");
        if (Convert.ToString(check) != "")
        {
            int claim1;
            int claim2;
            if (DeathCertificateButton.Checked)
            {
                claim1 = ob.FunExecuteNonQuery("update policyclaim set claimId = " + ClaimTypeText.SelectedValue.ToString() + ", deathCertificate = 'Available', name = '" + Name.Text + "', claimStatus = 'P' where CustomerId = " + Session["r"] + " and policyNo = " + PolicyNoText.Text + "");
                Literal1.Text = "Claim submitted for Admin Approval";
            }
            else
            {
                claim2 = ob.FunExecuteNonQuery("update policyclaim set claimId = " + ClaimTypeText.SelectedValue.ToString() + ", deathCertificate = 'NotAvailable', name = '" + Name.Text + "', claimStatus = 'P' where CustomerId = " + Session["r"] + " and policyNo = " + PolicyNoText.Text + "");
                Literal1.Text = "Claim submitted for Admin Approval";
            }
        }
        else
        {
            Literal1.Text = "Your request is not yet approved by Admin";
        }
    }
}
