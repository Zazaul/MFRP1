﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Data_access_layer;
public partial class Policy_registration : System.Web.UI.Page
{
    Data_acces_layer obj = new Data_acces_layer();
    SqlDataReader sdr;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["r"] == null) {
            Response.Redirect("Home.aspx");
        }
        #region Load Insurance name on page load
        if (!IsPostBack)
        {
            InsuranceNameDropdownList.DataSource = obj.FunDataTable("select * from insurancetype");
            InsuranceNameDropdownList.AppendDataBoundItems = true;
            InsuranceNameDropdownList.DataTextField = "insName";
            InsuranceNameDropdownList.DataValueField = "insName";
            InsuranceNameDropdownList.DataBind();
        }
        #endregion
    }

    protected void InsuranceNameDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate policy amount Dropdown list
        PolicyAmountDropdownList.Items.Clear();
        PolicyAmountDropdownList.DataSource = obj.FunDataTable("select polAmount from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + InsuranceNameDropdownList.SelectedValue.ToString() + "'");
        PolicyAmountDropdownList.AppendDataBoundItems = true;
        PolicyAmountDropdownList.Items.Insert(0, new ListItem("Select Policy Amount", null));
        PolicyAmountDropdownList.DataTextField = "polAmount";
        PolicyAmountDropdownList.DataValueField = "polAmount";
        PolicyAmountDropdownList.DataBind();
        #endregion
    }

    protected void PolicyAmountDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate policy Duration Dropdown list
        PolicyDurationDropdownList.Items.Clear();
        PolicyDurationDropdownList.DataSource = obj.FunDataTable("select * from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + InsuranceNameDropdownList.SelectedValue.ToString() + "'and polAmount = "+Convert.ToInt32(PolicyAmountDropdownList.SelectedValue) +"");
        PolicyDurationDropdownList.AppendDataBoundItems = true;
        PolicyDurationDropdownList.Items.Insert(0, new ListItem("Select Policy Duration", null));
        PolicyDurationDropdownList.DataTextField = "duration";
        PolicyDurationDropdownList.DataValueField = "duration";
        PolicyDurationDropdownList.DataBind();
        #endregion    
    }

    protected void PolicyDurationDropdownList_SelectedIndexChanged(object sender, EventArgs e)
    {
        #region Populate Premium Type Dropdown list
        PremiumTypeDropDownList.Items.Clear();
        PremiumTypeDropDownList.DataSource = obj.FunDataTable("select distinct(weightage.premiumType) from weightage");
        PremiumTypeDropDownList.AppendDataBoundItems = true;
        PremiumTypeDropDownList.Items.Insert(0, new ListItem("Select Premium Type", null));
        PremiumTypeDropDownList.DataTextField = "premiumType";
        PremiumTypeDropDownList.DataValueField = "premiumType";
        PremiumTypeDropDownList.DataBind();
        #endregion  
    }


    protected void ApplyButton_Click(object sender, EventArgs e)
    {
  
        int a = obj.FunExecuteNonQuery("insert into policy_registration values ("+Session["r"]+ ",'"+InsuranceNameDropdownList.SelectedItem.Text + "',"+Convert.ToInt32(PolicyAmountDropdownList.SelectedItem.Text)+","+Convert.ToInt32(PolicyDurationDropdownList.SelectedItem.Text)+",'"+PremiumTypeDropDownList.SelectedItem.Text+"','" + DateTime.Parse(PolicyStartDateTextBox.Text) + "'," + Convert.ToInt32(DiscountTextbox.Text) + "," + Convert.ToInt32(PremiumAmountTextbox.Text) + ",'" + DateTime.Parse(MaturityDateTextbox.Text) + "'," + Session["r"] + ",'" +DateTime.Now + "','P')");
           
        if (a > 0)
            {
               object count = obj.FunExecuteScalar("Select count(policyNo) from Policyclaim");
                int policy_no = 1000 + Convert.ToInt32(count);
                if (policy_no <= 99999)
                {
                    policy_No.Text = "Policy Number is " + Convert.ToString(policy_no);
                    int b = obj.FunExecuteNonQuery("Insert into Policyclaim(CustomerId,policyNo) values(" + Session["r"] + "," + policy_no + ")");
                }
                Response.Write("Registered successfuly");
            }
            else
            {
                Response.Write("Register again");
            }
        //int policy_no = 1000;
       
        //int a = obj.FunExecuteNonQuery("exec usp_P_r_insert '"+Convert.ToInt32()+"'");
      
    }
    protected void PolicyStartDateTextBox_TextChanged(object sender, EventArgs e)
    {
        #region Submit policy registration
        object percentage = obj.FunExecuteScalar("select percentage from weightage w join durationweightage dur on w.weightage=dur.discountWeightage join policyamount pol on pol.duration=dur.duration join insurancetype ins on ins.insType=pol.insType where w.premiumType='" + PremiumTypeDropDownList.SelectedValue.ToString() + "' and pol.polAmount=" + PolicyAmountDropdownList.SelectedValue.ToString() + " and ins.insName='" + InsuranceNameDropdownList.SelectedValue.ToString() + "'and dur.duration='" + PolicyDurationDropdownList.SelectedValue.ToString() + "'");
        double premiumamount = obj.calulatePremiuim(double.Parse(PolicyAmountDropdownList.SelectedValue), int.Parse(PolicyDurationDropdownList.SelectedValue), Convert.ToString(PremiumTypeDropDownList.SelectedValue), Convert.ToSingle(percentage));
        DiscountTextbox.Text = Convert.ToString((int)percentage);
        PremiumAmountTextbox.Text = Convert.ToString((int)premiumamount);
        DateTime start_date = DateTime.Parse(PolicyStartDateTextBox.Text);
        DateTime MaturityDate = obj.MaturityDate(start_date, Convert.ToInt32(PolicyDurationDropdownList.SelectedValue));
        MaturityDateTextbox.Text = Convert.ToString(MaturityDate);
         #endregion
    }
}