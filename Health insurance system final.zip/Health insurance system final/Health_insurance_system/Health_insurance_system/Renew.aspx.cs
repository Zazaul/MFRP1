﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;
public partial class Renew : System.Web.UI.Page
{
    Data_acces_layer obj = new Data_acces_layer();

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void PolicyId_TextChanged(object sender, EventArgs e)
    {
        #region Check policyid if okay then fill Amount duration and type dropdown
        object a = obj.FunExecuteScalar("select CustomerId from policyclaim where policyNo = " + int.Parse(PolicyId.Text) + " and CustomerId = " + Session["r"] + "");
        if (Convert.ToString(a) == "")
        {
            Literal1.Text = "Please Enter a valid Policy Id";
        }
        else
        {
            Insurancetype.Items.Clear();
            Insurancetype.DataSource = obj.FunDataTable("select insuranceName from policy_registration where customerId = " + Session["r"] + "");
            Insurancetype.Items.Insert(0, new ListItem("Select Insurance Type", null));
            Insurancetype.AppendDataBoundItems = true;
            Insurancetype.DataTextField = "insuranceName";
            Insurancetype.DataValueField = "insuranceName";
            Insurancetype.DataBind();
        }
        #endregion
    }

    protected void Insurancetype_SelectedIndexChanged(object sender, EventArgs e)
    {
        Policyamount.Items.Clear();
        Policyamount.DataSource = obj.FunDataTable("select polAmount from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + Insurancetype.SelectedValue + "'");
        Policyamount.Items.Insert(0, new ListItem("Select Policy Amount", null));
        Policyamount.AppendDataBoundItems = true;
        Policyamount.DataTextField = "polAmount";
        Policyamount.DataValueField = "polAmount";
        Policyamount.DataBind();
    }

    protected void Policyamount_SelectedIndexChanged(object sender, EventArgs e)
    {
        Policyduration.Items.Clear();
        Policyduration.DataSource = obj.FunDataTable("select duration from insurancetype join policyamount on insurancetype.insType = policyamount.insType where insName = '" + Insurancetype.SelectedValue + "' and polAmount = " + Policyamount.SelectedValue + "");
        Policyduration.Items.Insert(0, new ListItem("Select Policy Duration", null));
        Policyduration.AppendDataBoundItems = true;
        Policyduration.DataTextField = "duration";
        Policyduration.DataValueField = "duration";
        Policyduration.DataBind();

        Premiumtype.Items.Clear();
        Premiumtype.DataSource = obj.FunDataTable("select distinct premiumType from weightage");
        Premiumtype.Items.Insert(0, new ListItem("Select Premium Type", null));
        Premiumtype.AppendDataBoundItems = true;
        Premiumtype.DataTextField = "premiumType";
        Premiumtype.DataValueField = "premiumType";
        Premiumtype.DataBind();
    }

    protected void Apply_Click1(object sender, EventArgs e)
    {
        int percentage = Convert.ToInt32(obj.FunExecuteScalar("select percentage from durationweightage join weightage on durationweightage.discountWeightage = weightage.weightage  where duration = " + Convert.ToInt32(Policyduration.Text) + " and premiumtype = '" + Premiumtype.Text + "'"));
        int premium = Convert.ToInt32(obj.calulatePremiuim(Convert.ToDouble(Policyamount.Text), Convert.ToDouble(Policyduration.Text), Premiumtype.Text,percentage));
        DateTime matdate = obj.MaturityDate(DateTime.Parse(Policyrenewdate.Text), Convert.ToInt32(Policyduration.Text));
        DateTime updateOn = DateTime.Now;
        int a = obj.FunExecuteNonQuery("update policy_registration set policyAmount = " + Convert.ToInt32(Policyamount.SelectedValue) + ", policyDuration = " + Convert.ToInt32(Policyduration.SelectedValue) + ", premiumType = '" + Premiumtype.SelectedValue + "', policyStart_Date = '" + DateTime.Parse(Policyrenewdate.Text) + "',discount = " + percentage + ",premiumAmount=" + premium + ",maturityDate = '" + matdate + "', updateBy = " + Session["r"] + ", updateOn = '" + updateOn + "' where insuranceName = '" + Insurancetype.SelectedValue + "' and customerId = " + Session["r"] + "");
        if (a > 0)
        {
            Literal1.Text = "Policy Submitted for Admin Approval";
        }
        else
        {
            Literal1.Text = "Policy renewal failed";
        }
    }
}