﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using Data_access_layer;
public partial class Admin : System.Web.UI.Page
{
    SqlDataReader dr;
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["A"] == null)
        {
            Response.Redirect("Home.aspx");
        }

        if (!IsPostBack)
        {
            DataTable dt = new DataTable();

            dt = ob.FunDataTable("select customerId, insuranceName from policy_registration where sta = 'P'");
            if (dt.Rows.Count > 0)
            {
                GridView3.DataSource = dt;
                GridView3.DataBind();
            }
            else
                Literal1.Text = "No pending data";

            dt = ob.FunDataTable("select pc.CustomerId, pc.policyNo, ct.claimtype from policyclaim pc join claim_type ct on pc.claimId = ct.ClaimId where claimStatus = 'P';");
            if (dt.Rows.Count > 0)
            {
                GridView4.DataSource = dt;
                GridView4.DataBind();
            }
            else
                Literal2.Text = "No pending data";
        }    
    }

    protected void GridView3_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        string id = GridView3.Rows[e.NewSelectedIndex].Cells[0].Text;
        //Response.Redirect(");
        string insName = GridView3.Rows[e.NewSelectedIndex].Cells[1].Text;
        //Response.Write(name);
        Session["id"] = id; Session["insName"] = insName;
        Response.Redirect("PolicyDetail.aspx");
    }

    protected void GridView4_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        string id = GridView4.Rows[e.NewSelectedIndex].Cells[0].Text;
        //Response.Redirect(");
        string policyNo = GridView4.Rows[e.NewSelectedIndex].Cells[1].Text;
        //Response.Write(name);
        Session["id"] = id; Session["polNum"] = policyNo;
        Response.Redirect("ClaimDetail.aspx");
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Home.aspx");
    }
}