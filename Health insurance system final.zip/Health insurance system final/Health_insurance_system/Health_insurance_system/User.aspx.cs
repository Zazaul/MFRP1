﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Data_access_layer;
public partial class User : System.Web.UI.Page
{
    Data_acces_layer obj = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["r"] == null)
            Response.Redirect("Userlogin.aspx");
        else
        {
            Literal2.Text = Convert.ToString(obj.FunExecuteScalar("select Name from customer_registration where Customer_Id = " + Session["r"] + ""));
            if (!IsPostBack)
            {
                DataTable dt = new DataTable();
                dt = obj.FunDataTable("select insuranceName as Insurance_Name, sta as Status from policy_registration where CustomerId = " + Session["r"] + "");
                if (dt.Rows.Count > 0)
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
                else
                    Literal3.Text = "You don't have any policy registered";
                dt = obj.FunDataTable("select pc.claimId as ID, claimtype as Name, pc.claimStatus as Status from policyclaim pc join claim_type ct on pc.ClaimId = ct.ClaimId where CustomerId = " + Session["r"] + "");
                if (dt.Rows.Count > 0)
                {
                    GridView2.DataSource = dt;
                    GridView2.DataBind();
                }
                else
                    Literal4.Text = "You don't have any policy claims";
            }
        }

    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {
    }
}