﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;
public partial class EditUser : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int a = 0, b = 0, c = 0;
        if (user_name.Text != "")
        {
            a = ob.FunExecuteNonQuery("update customer_registration set Name ='" + user_name.Text + "' where customer_Id=" + Session["r"] + "");
        }
        if (mail.Text != "")
        {
            b = ob.FunExecuteNonQuery("update customer_registration set Email ='" + mail.Text + "' where customer_Id=" + Session["r"] + "");
        }
        if (phone.Text != "")
        {
            c = ob.FunExecuteNonQuery("update customer_registration set Contact_No =" + phone.Text + " where customer_Id=" + Session["r"] + "");
        }
        if (a > 0 || b > 0 || c > 0)
            Literal1.Text = "Your details have been updated successfully";
        else
            Literal1.Text = "Profile updation unsuccessful";
    }
    protected void ChangePassword_Click(object sender, EventArgs e)
    {
        Response.Redirect("User_password.aspx");
    }
}