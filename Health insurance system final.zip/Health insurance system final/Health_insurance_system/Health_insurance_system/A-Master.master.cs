﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Data_access_layer;
public partial class A_Master : System.Web.UI.MasterPage
{
    Data_acces_layer obj = new Data_acces_layer();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["r"] == null)
            Response.Redirect("Userlogin.aspx");
        else
        {
            string uname = Convert.ToString(obj.FunExecuteScalar("select Name from customer_registration where Customer_Id = " + Session["r"] + ""));
            username.Text = uname + "(" + Session["r"].ToString() + ")";
        }
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        Session.Abandon();
        Response.Redirect("Home.aspx");
    }
}
