﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Data;
using Data_access_layer;

public partial class Customer_registration1 : System.Web.UI.Page
{
    Data_acces_layer ob = new Data_acces_layer();
    SqlDataReader dr;
    DataSet ds;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            CountryD1.DataSource = ob.FunDataTable("select * from countrymaster");
            CountryD1.AppendDataBoundItems = true;
            CountryD1.DataTextField = "countryName";
            CountryD1.DataValueField = "countryId";
            CountryD1.DataBind();


            GenderD1.DataSource = ob.FunDataTable("select * from gender");
            GenderD1.AppendDataBoundItems = true;
            GenderD1.DataTextField = "name";
            GenderD1.DataValueField = "Gender_Id";
            GenderD1.DataBind();
        }

    }
    #region custom validation (password)
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        int UC = 0;
        int LC = 0;
        int number = 0;
        string password = args.Value.ToString();
        char[] c = password.ToCharArray();
        for (int i = 0; i < c.Length; i++)
        {
            if (c[i] >= 'A' && c[i] <= 'Z')
            {
                UC++;
            }
            if (c[i] >= 'a' && c[i] <= 'z')
            {
                LC++;
            }
            if (c[i] >= '0' && c[i] <= '9')
            {
                number++;
            }
        }
        if (UC > 0 && LC > 0 && number > 0)
        {
            args.IsValid = true;


        }
        else
        {
            args.IsValid = false;


        }
    }
    #endregion

    #region custom validation (address)
    protected void CustomValidator2_ServerValidate(object source, ServerValidateEventArgs args)
    {
        string password = args.Value.ToString();
        string format = "^[A-Za-z ,/0-9]{1,}$";
        bool check = Regex.IsMatch(password, format);
        if (check)
            args.IsValid = true;

        else
            args.IsValid = false;
    }
    #endregion

    #region custom validation (Name)
    protected void CustomValidator3_ServerValidate(object source, ServerValidateEventArgs args)
    {
        string password = args.Value.ToString();
        string format = "^[A-Z a-z]{1,}$";
        bool check = Regex.IsMatch(password, format);
        if (check)
            args.IsValid = true;
        else
            args.IsValid = false;
    }
    #endregion

    #region custom validation (Age)
    protected void CustomValidator4_ServerValidate1(object source, ServerValidateEventArgs args)
    {
        DateTime date = DateTime.Parse(args.Value.ToString());
        DateTime currentdate = DateTime.Now;
        TimeSpan t = currentdate - date;
        float years = (float)t.Days / (float)365.25;
        if (years < (float)90)
        {
            args.IsValid = true;

        }
        else
        {
            args.IsValid = false;


        }

    }
    #endregion

    #region Register button
    protected void Registerbutton_Click(object sender, EventArgs e)
    {
        string s = CustomerIdtext.Text;
        int a1 = int.Parse(s);
        object ds1 = ob.FunExecuteScalar("select Customer_Id from customer_registration where Customer_Id=" + a1 + "");
        string test = Convert.ToString(ds1);
        if (Convert.ToString(ds1) != "")
        {
            Literal1.Text = "Customer Already Present";
        }
        else
        {
            if (Page.IsValid)
            {
                int a = ob.FunExecuteNonQuery("insert into customer_registration values (" + Convert.ToInt32(CustomerIdtext.Text) + ",'" + Nametext.Text + "','" + Password.Text + "','" + Addresstext.Text + "'," + Convert.ToInt32(CountryD1.SelectedValue.ToString()) + "," + Convert.ToInt32(StateD1.SelectedValue.ToString()) + "," + Convert.ToInt32(CitytextD1.SelectedValue.ToString()) + "," + Convert.ToInt32(PinCodetext.Text) + ",'" + EmailIdtext.Text + "'," + Convert.ToInt32(GenderD1.SelectedValue.ToString()) + "," + Convert.ToInt64(ContactNumbertext.Text) + ",'" + DateTime.Parse(Dateofbirth.Text) + "','" + CustomerTypeD1.SelectedValue.ToString() + "','Y','C')");
                if (a > 0)
                {
                    Literal1.Text = "Registered Succesfully";
                    HyperLink1.Visible = true;
                }
                else
                {
                    Literal1.Text = "Register again";
                }
            }
            else
            {
                Literal1.Text = "Register again";
            }
        }
    }
    #endregion


    protected void CountryD1_SelectedIndexChanged(object sender, EventArgs e)
    {
        StateD1.Items.Clear();
        StateD1.DataSource = ob.FunDataTable("select * from statemaster where countryId=" + Convert.ToInt32(CountryD1.SelectedValue.ToString()) + "");

        StateD1.AppendDataBoundItems = true;
        StateD1.Items.Insert(0, new ListItem("Select a State", null));
        StateD1.DataTextField = "stateName";
        StateD1.DataValueField = "stateId";
        StateD1.DataBind();


    }
    protected void StateD1_SelectedIndexChanged(object sender, EventArgs e)
    {
        CitytextD1.Items.Clear();
        CitytextD1.DataSource = ob.FunDataTable("select * from citymaster where stateId=" + Convert.ToInt32(StateD1.SelectedValue.ToString()) + "and countryId=" + Convert.ToInt32(CountryD1.SelectedValue.ToString()) + "");

        CitytextD1.AppendDataBoundItems = true;
        CitytextD1.Items.Insert(0, new ListItem("Select a City", null));

        CitytextD1.DataTextField = "cityName";
        CitytextD1.DataValueField = "cityId";
        CitytextD1.DataBind();

    }

    protected void CitytextD1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

}