﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using Data_access_layer;

public partial class Login : System.Web.UI.Page
{
    Data_acces_layer dalObj = new Data_acces_layer();

    SqlDataReader dr;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Register_Click(object sender, EventArgs e)
    {
        Response.Redirect("Customer_registration1.aspx");
    }
    protected void Reset_Click(object sender, EventArgs e)
    {
        Userid.Text = "";
        Password.Text = "";
    }
    protected void Submit_Click(object sender, EventArgs e)
    {
        dr = dalObj.ExecuteReader("select Customer_Id from customer_registration where Customer_Id=" + Userid.Text + " and Password='" + Password.Text + "' and Role='C'");
        if (dr.Read())
        {
            dalObj.CloseConnection();
            dr = dalObj.ExecuteReader("select Customer_Id from customer_registration where Customer_Id=" + Userid.Text + " and Password='" + Password.Text + "' and Role='C' and Active='Y'");
            if (dr.Read())
            {
                Session["r"] = dr[0];
                Response.Redirect("User.aspx");
                dalObj.CloseConnection();
            }
            else
            {
                Invalidcredential.Text = "Inactive Account";
            }
        }
        else
            Invalidcredential.Text = "Invalid UserID/Password";
    }

}